// zadatak 0
public class Main {}
